# Transaction Monitor

This is an independent portfolio project. The hosted UI is a browser demo with simulated data. It does not claim work for Capital One.

Open `index.html` to try the standalone demo. The `transaction-monitor/` directory contains the separate backend service.

Run its Dockerfile with `docker build -t transaction-monitor .` and `docker run -p 8080:8080 transaction-monitor` from that backend directory. For persistence, mount `/data` for the transaction and pipeline APIs. See the code and root README in the full bundle for details.
